import java.util.Scanner;

public class Ex11 {
    public static void main(String[] args) {

        // 11) Imprimir números de 1 a 10
        // Objetivo: Utilizar um loop for para imprimir os números de 1 a 10.

        Scanner teclado = new Scanner(System.in);

        for (int i = 1; i <= 10; i++) {
            System.out.println(i);

        }
    }
}
